const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function sortCharacter(input) {
    input = input.toLowerCase();

    let vowelsChar = "";
    let consonantsChar = "";

    for (let i = 0; i < input.length; i++) {
        const letter = input[i];
        if(letter === ' '){
            continue;
        };
        if("aiueo".indexOf(letter) != -1){
            vowelsChar += letter;
        }else{
            consonantsChar += letter;
        }

        
    }
    console.log("Vowel Characters: " + vowelsChar);
    console.log("Consonant Characters: " + consonantsChar);
}

rl.question("Enter the word/sentence :", (input) =>{
    sortCharacter(input);
    rl.close();
});
