const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function PSBB(family, members) {
    members = members.split(' ').map(Number);

    if (members.length !== family) {
        console.log("Input must be equal with count of family");
        return;
    }

    members.sort((member1, member2) => member1 - member2);
    let i = 0;
    let j = family - 1;
    let bus = 0;

    while(i <= j){
        if (members[i] + members[j] <= 4) {
            i++;
        }
        j--;
        bus++;
    }
    
    console.log("Minimum bus required is : " + bus);
    
}

rl.question("Input the number of families :", (family) =>{
    family = parseInt(family);
    rl.question("Input the number of members in the family (separated by a space) :", (members) => {
        PSBB(family, members);
        rl.close();
    });
});

